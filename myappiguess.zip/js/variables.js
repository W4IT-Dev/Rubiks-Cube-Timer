let timing = spacedown = canStart = false;
let times = [];
const sessiondetails = document.querySelector('#session-details');
const scramble = document.querySelector('#scramble');
const timerContainer = document.querySelector('#timer-container');